// You can add dynamic features here later
console.log("Family site loaded!");
